
var kbType = 'Letters';
var kbOrientation = 1;//Portrait.. 2=Landscape
var kbNumType = 431
var lang = '';
var type10Lang = ['fr', 'es'];
var type10Num = [431, 432, 345, 346, 388, 389];
var kb2Type = 'Alphabetic';

$('#letters').show();

function laetusCurrentLanguage(language) {
    lang = language.split('_')[0];
    updateKeyboard();
}

function laetusRawKeyPlaneDidChange(state) {
    var keyPlane = state.split('-');
    var lastItem = keyPlane[keyPlane.length - 1];
    kb2Type = keyPlane[1];
    kbNumType = Number(keyPlane[0].split('_')[0]);
    kbType = lastItem;
    if (state.indexOf('Portrait') != -1) {
        kbOrientation = 1
    }
    else {
        kbOrientation = 2;
    }

    updateKeyboard();
}

function updateKeyboard() {
    var lastItem = kbType;
    switch (lastItem) {
        case 'Punctuation':
            if (kb2Type == 'Alphabetic') {
                if (kbOrientation == 1) {
                    $('#numbers').show();
                    $('#numbersLandscape').hide();
                    $('#lettersLandscape').hide();
                    $('#letters').hide();
                    $('#numpad').hide();
                    if (type10Num.indexOf(kbNumType) != -1) {
                        $('.numShow8').hide();
                        $('.numShow10').show();
                    }
                    else {
                        $('.numShow10').hide();
                        $('.numShow8').show();
                    }
                }
                else {
                    $('#numbersLandscape').show();
                    $('#lettersLandscape').hide();
                    $('#letters').hide();
                    $('#numbers').hide();
                    $('#numpad').hide();
                    if (type10Num.indexOf(kbNumType) != -1) {
                        $('.numShow8').hide();
                        $('.numShow10').show();
                    }
                    else {
                        $('.numShow10').hide();
                        $('.numShow8').show();
                    }
                }
            }
            break;
        case 'Alternate':
            if (kb2Type == 'Alphabetic') {
                if (kbOrientation == 1) {
                    $('#numbers').show();
                    $('#numbersLandscape').hide();
                    $('#lettersLandscape').hide();
                    $('#letters').hide();
                    $('#numpad').hide();
                    if (type10Num.indexOf(kbNumType) != -1) {
                        $('.numShow8').hide();
                        $('.numShow10').show();
                    }
                    else {
                        $('.numShow10').hide();
                        $('.numShow8').show();
                    }
                }
                else {
                    $('#numbersLandscape').show();
                    $('#lettersLandscape').hide();
                    $('#letters').hide();
                    $('#numbers').hide();
                    $('#numpad').hide();
                    if (type10Num.indexOf(kbNumType) != -1) {
                        $('.numShow8').hide();
                        $('.numShow10').show();
                    }
                    else {
                        $('.numShow10').hide();
                        $('.numShow8').show();
                    }
                }
            }
            break;
        case 'Display':
            if (kb2Type == 'Alphabetic') {
                if (kbOrientation == 1) {
                    $('#numbers').hide();
                    $('#numbersLandscape').hide();
                    $('#lettersLandscape').hide();
                    $('#letters').show();
                    $('#numpad').hide();
                    if (type10Lang.indexOf(lang) != -1) {
                        $(".show9").hide();
                        $(".show10").show();
                    } else {
                        $(".show9").show();
                        $(".show10").hide();
                    }
                }
                else {
                    $('#numbersLandscape').hide();
                    $('#lettersLandscape').show();
                    $('#letters').hide();
                    $('#numbers').hide();
                    $('#numpad').hide();
                    if (type10Lang.indexOf(lang) != -1) {
                        $(".show9").hide();
                        $(".show10").show();
                    } else {
                        $(".show9").show();
                        $(".show10").hide();
                    }
                }
            }
            break;
        case 'Letters':
            if (kb2Type == 'Alphabetic') {
                if (kbOrientation == 1) {
                    $('#numbers').hide();
                    $('#numbersLandscape').hide();
                    $('#lettersLandscape').hide();
                    $('#letters').show();
                    $('#numpad').hide();
                    if (type10Lang.indexOf(lang) != -1) {
                        $(".show9").hide();
                        $(".show10").show();
                    } else {
                        $(".show9").show();
                        $(".show10").hide();
                    }
                }
                else {
                    $('#numbersLandscape').hide();
                    $('#lettersLandscape').show();
                    $('#letters').hide();
                    $('#numbers').hide();
                    $('#numpad').hide();
                    if (type10Lang.indexOf(lang) != -1) {
                        $(".show9").hide();
                        $(".show10").show();
                    } else {
                        $(".show9").show();
                        $(".show10").hide();
                    }
                }
            }
            break;
        case 'Pad_Default':
            if (kbOrientation == 1) {
                $('#numpad').show();
                $('#numbers').hide();
                $('#numbersLandscape').hide();
                $('#lettersLandscape').hide();
                $('#letters').hide();
            }
            else {
                $('#numbers').hide();
                $('#numbersLandscape').hide();
                $('#lettersLandscape').hide();
                $('#letters').hide();
                $('#numpad').hide();
            }
            break;
        case 'Keyboard_Letters':

            $('#numbers').hide();
            $('#numbersLandscape').hide();
            $('#lettersLandscape').hide();
            $('#letters').hide();
            $('#numpad').hide();

            break;
    }
}